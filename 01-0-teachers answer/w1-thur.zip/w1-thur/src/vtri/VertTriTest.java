package vtri;

public class VertTriTest {

	public static void main(String[] args) {
		VertTri vtri1 = new VertTri(5,3);
        vtri1.draw();
        System.out.println();
		VertTri vtri2 = new VertTri(5,4);
        vtri2.draw();
        
        
	}

}
