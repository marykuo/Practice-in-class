package vtri;

public class VertTri {

   private int height;
   private int type;
   private String ch="*";
   
   private final int UpLeft = 1;
   private final int UpRight = 2;
   private final int DownLeft = 3;
   private final int DownRight = 4;
   
   public VertTri(int height, int type){
	   this.height = height;
	   this.type = type;
   }

   public VertTri(int height, int type, String ch){
	   
   }
   
   public void draw(){
	   switch(type){
	   case UpLeft:
		   
		   break;
	   case UpRight:
		   
		   break;
	   
	   case DownLeft:
			for(int i=1;i<=height;i++){
				prchar(ch,height-i+1);
				System.out.printf("\n");
			}		

		   break;
	   case DownRight:
			for(int i=1;i<=height;i++){
				prchar(" ", i-1);
				prchar(ch,height-i+1);
				System.out.printf("\n");
			}		
		   break;
	   }
   }
   
	void prchar(String c, int n){
		for(int i=1;i<=n;i++)
			System.out.printf("%s", c);
	}

}
