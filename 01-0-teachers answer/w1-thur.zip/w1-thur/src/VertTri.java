
public class VertTri {

	public static void main(String[] args) {
		int height = 8;
		//System.out.printf("Enter height: ");
		//scanf("%d", &height);
	    drawVerTri(height);
	}

	static void prchar(char c, int n){
		for(int i=1;i<=n;i++)
			System.out.printf("%c", c);
	}
	
	static void drawVerTri(int height){
		for(int i=1;i<=height;i++){
			prchar(' ', i-1);
			prchar('*',height-i+1);
			System.out.printf("  ");
			prchar('*',height-i+1);
			System.out.printf("\n");
		}		
	}
	
}

/*
#include <stdio.h>





int main(){
	
}
 
 
 
 */
