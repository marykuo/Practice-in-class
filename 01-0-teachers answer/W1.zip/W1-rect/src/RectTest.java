
public class RectTest {

	public static void main(String[] args) {
		Rect rect;
		rect = new Rect(5,10);
		rect.draw();

	}

}
