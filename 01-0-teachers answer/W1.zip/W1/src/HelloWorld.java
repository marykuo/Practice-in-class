
public class HelloWorld {

	public static void main(String[] args) {
		System.out.printf("Welcome to Java Programming\n");
	}
}
